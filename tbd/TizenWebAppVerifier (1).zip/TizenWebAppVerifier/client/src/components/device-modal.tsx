import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Device } from "@shared/schema";

interface DeviceModalProps {
  isOpen: boolean;
  onClose: () => void;
  devices: Device[];
  onDeviceSelect: (device: Device) => void;
}

interface SDBDevice {
  serial: string;
  status: string;
  name: string;
}

export default function DeviceModal({ isOpen, onClose, devices, onDeviceSelect }: DeviceModalProps) {
  const [ipAddress, setIpAddress] = useState("");
  const [packageId, setPackageId] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch SDB devices
  const { data: sdbDevices = [], isLoading: sdbLoading, refetch: refetchSDB } = useQuery<SDBDevice[]>({
    queryKey: ['/api/sdb/devices'],
    enabled: isOpen,
  });

  // Connect device mutation
  const connectDeviceMutation = useMutation({
    mutationFn: async (ipAddress: string) => {
      console.log('Frontend: Connecting to device:', ipAddress);
      const result = await apiRequest('/api/sdb/connect', { 
        method: 'POST', 
        body: JSON.stringify({ ipAddress }),
        headers: { 'Content-Type': 'application/json' }
      });
      
      console.log('Frontend: Connect result:', result);
      
      if (!result.success) {
        throw new Error('Device connection failed');
      }
      
      return result;
    },
    onSuccess: (data) => {
      console.log('Frontend: Device connected successfully:', data);
      toast({
        title: "Success",
        description: "Device connected successfully",
      });
      refetchSDB();
      setIpAddress("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to connect device",
        variant: "destructive",
      });
    },
  });

  // Disconnect device mutation
  const disconnectDeviceMutation = useMutation({
    mutationFn: async (serial: string) => {
      console.log('Frontend: Disconnecting device:', serial);
      const result = await apiRequest(`/api/sdb/disconnect/${serial}`, { method: 'POST' });
      console.log('Frontend: Disconnect result:', result);
      return result;
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Device disconnected successfully",
      });
      refetchSDB();
      queryClient.invalidateQueries({ queryKey: ['/api/devices'] });
    },
  });

  // Launch debug mutation
  const launchDebugMutation = useMutation({
    mutationFn: async ({ serial, packageId }: { serial: string; packageId: string }) => {
      console.log('Frontend: Launching debug for', packageId, 'on', serial);
      
      const response = await fetch(`/api/sdb/debug/${serial}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ packageId }),
        credentials: 'include'
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Launch failed');
      }
      
      const result = await response.json();
      console.log('Frontend: Debug launch successful:', result);
      return result;
    },
    onSuccess: (data) => {
      toast({
        title: "Success",
        description: `Debug mode launched on port ${data.port}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/devices'] });
    },
    onError: (error: any) => {
      console.error('Debug launch error:', error);
      toast({
        title: "Error", 
        description: error?.message || "Failed to launch debug mode",
        variant: "destructive",
      });
    },
  });

  const handleConnect = () => {
    if (ipAddress.trim()) {
      connectDeviceMutation.mutate(ipAddress.trim());
    }
  };

  const handleDisconnect = (serial: string) => {
    disconnectDeviceMutation.mutate(serial);
  };

  const handleLaunchDebug = (serial: string) => {
    if (packageId.trim()) {
      launchDebugMutation.mutate({ serial, packageId: packageId.trim() });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-2xl" data-testid="device-modal">
        <DialogHeader>
          <DialogTitle>Device Management</DialogTitle>
          <p className="text-sm text-muted-foreground">Connect and manage Tizen devices via SDB</p>
        </DialogHeader>

        <div className="space-y-6">
          {/* Connected Devices */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-medium">SDB Devices</h4>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => refetchSDB()}
                disabled={sdbLoading}
                data-testid="button-refresh-devices"
              >
                Refresh
              </Button>
            </div>
            
            {sdbLoading ? (
              <div className="text-center py-4 text-muted-foreground">Loading devices...</div>
            ) : sdbDevices.length > 0 ? (
              <div className="space-y-2">
                {sdbDevices.map((device) => (
                  <div 
                    key={device.serial} 
                    className="flex items-center justify-between p-3 bg-muted rounded-lg"
                    data-testid={`sdb-device-${device.serial}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`status-indicator ${
                        device.status === 'device' ? 'status-connected' : 'status-disconnected'
                      }`} />
                      <div>
                        <div className="font-medium">{device.name}</div>
                        <div className="text-sm text-muted-foreground font-mono">{device.serial}</div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {device.status === 'device' && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDisconnect(device.serial)}
                          disabled={disconnectDeviceMutation.isPending}
                          data-testid={`button-disconnect-${device.serial}`}
                        >
                          Disconnect
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-4 text-muted-foreground">No SDB devices found</div>
            )}
          </div>

          {/* Connect Device */}
          <div>
            <h4 className="font-medium mb-3">Connect Device</h4>
            <div className="flex space-x-2">
              <Input
                type="text"
                placeholder="Device IP (192.168.1.10)"
                value={ipAddress}
                onChange={(e) => setIpAddress(e.target.value)}
                disabled={connectDeviceMutation.isPending}
                data-testid="input-device-ip"
              />
              <Button 
                onClick={handleConnect}
                disabled={connectDeviceMutation.isPending || !ipAddress.trim()}
                data-testid="button-connect-device"
              >
                Connect
              </Button>
            </div>
          </div>

          {/* Launch Debug Mode */}
          {sdbDevices.some(d => d.status === 'device') && (
            <div>
              <h4 className="font-medium mb-3">Launch Debug Mode</h4>
              <div className="flex space-x-2">
                <Input
                  type="text"
                  placeholder="Package ID (com.example.app)"
                  value={packageId}
                  onChange={(e) => setPackageId(e.target.value)}
                  disabled={launchDebugMutation.isPending}
                  data-testid="input-package-id"
                />
                <Button 
                  onClick={() => {
                    const connectedDevice = sdbDevices.find(d => d.status === 'device');
                    if (connectedDevice) {
                      handleLaunchDebug(connectedDevice.serial);
                    }
                  }}
                  disabled={launchDebugMutation.isPending || !packageId.trim()}
                  data-testid="button-launch-debug"
                >
                  Launch Debug
                </Button>
              </div>
            </div>
          )}

          {/* Quick Commands */}
          <div>
            <h4 className="font-medium mb-3">Quick Commands</h4>
            <div className="grid grid-cols-2 gap-2">
              <Button variant="outline" size="sm" data-testid="button-list-devices">List Devices</Button>
              <Button variant="outline" size="sm" data-testid="button-install-app">Install App</Button>
              <Button variant="outline" size="sm" data-testid="button-view-logs">View Logs</Button>
              <Button variant="outline" size="sm" data-testid="button-take-screenshot">Take Screenshot</Button>
            </div>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-border">
          <Button variant="outline" onClick={onClose} data-testid="button-close-modal">
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
