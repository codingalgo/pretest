import type { Device } from "@shared/schema";

interface DevicePanelProps {
  device: Device | null;
}

export default function DevicePanel({ device }: DevicePanelProps) {
  return (
    <div className="w-96 bg-card border-l border-border flex flex-col" data-testid="device-panel">
      {/* Panel Tabs */}
      <div className="border-b border-border">
        <div className="flex">
          <button className="tab-active px-4 py-3 text-sm font-medium border-b-2 border-accent" data-testid="tab-device-preview">
            Device Preview
          </button>
          <button className="px-4 py-3 text-sm font-medium text-muted-foreground hover:text-foreground" data-testid="tab-logs">
            Logs
          </button>
          <button className="px-4 py-3 text-sm font-medium text-muted-foreground hover:text-foreground" data-testid="tab-results">
            Results
          </button>
        </div>
      </div>

      {/* Device Preview */}
      <div className="p-4 flex-1">
        {device ? (
          <>
            <div className="bg-muted rounded-lg p-4 aspect-square max-w-full">
              {/* Mock device frame for Galaxy Watch */}
              <div className="bg-black rounded-full aspect-square mx-auto relative max-w-48 border-4 border-gray-600">
                <div className="absolute inset-2 bg-background rounded-full overflow-hidden">
                  {/* Mock app interface highlighting an element being tested */}
                  <div className="h-full bg-gradient-to-b from-primary/20 to-accent/20 flex flex-col items-center justify-center p-4 text-center">
                    <div className="w-12 h-12 bg-primary rounded-full mb-3 flex items-center justify-center">
                      <svg className="w-6 h-6 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    {/* Highlighted element under test */}
                    <div className="border-2 border-primary rounded-md p-2 bg-primary/10 text-xs" data-testid="highlighted-element">
                      App Interface
                    </div>
                    <div className="text-xs text-muted-foreground mt-2" data-testid="element-selector">
                      Ready for testing
                    </div>
                  </div>
                </div>
                {/* Watch crown and button */}
                <div className="absolute right-0 top-1/3 w-2 h-8 bg-gray-600 rounded-l-md" />
                <div className="absolute right-0 top-2/3 w-2 h-4 bg-gray-600 rounded-l-md" />
              </div>
            </div>

            {/* Device Status */}
            <div className="mt-4 space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Connection:</span>
                <span className={device.status === 'connected' ? 'text-green-500' : 'text-red-500'} data-testid="connection-status">
                  {device.status === 'connected' ? 'SDB Connected' : 'Disconnected'}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Device:</span>
                <span className="font-mono text-xs" data-testid="device-name">
                  {device.name}
                </span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Serial:</span>
                <span className="font-mono text-xs" data-testid="device-serial">
                  {device.serial}
                </span>
              </div>
              {device.debugPort && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Debug Port:</span>
                  <span className="font-mono text-green-500" data-testid="debug-port">
                    {device.debugPort}
                  </span>
                </div>
              )}
            </div>

            {/* SDB Commands Panel */}
            <div className="mt-6">
              <h4 className="text-sm font-medium mb-3">SDB Commands</h4>
              <div className="code-block rounded-md p-3 text-xs font-mono space-y-1" data-testid="sdb-commands">
                <div className="text-green-500">$ sdb devices</div>
                <div className="text-muted-foreground">{device.serial} device {device.name}</div>
                {device.debugPort && (
                  <>
                    <div className="text-green-500">$ sdb shell 0 debug {device.serial}</div>
                    <div className="text-muted-foreground">successfully launched with debug port: {device.debugPort}</div>
                    <div className="text-green-500">$ sdb forward tcp:{device.debugPort} tcp:{device.debugPort}</div>
                  </>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <svg className="w-16 h-16 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
            <h3 className="text-lg font-medium mb-2">No Device Connected</h3>
            <p className="text-sm">Connect a Tizen device to start testing</p>
          </div>
        )}
      </div>
    </div>
  );
}
