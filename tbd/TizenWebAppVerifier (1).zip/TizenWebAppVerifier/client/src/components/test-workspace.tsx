import { useState } from "react";
import { useDragDrop } from "@/lib/drag-drop";
import type { TestScenario, TestStepData } from "@shared/schema";
import { cn } from "@/lib/utils";

interface TestWorkspaceProps {
  scenario: TestScenario | null;
  onScenarioChange: (scenario: TestScenario) => void;
  testSteps: TestStepData[];
  onTestStepsChange: (steps: TestStepData[]) => void;
}

interface TestStepWithStatus extends TestStepData {
  id: string;
  status: 'pending' | 'running' | 'passed' | 'failed';
  errorMessage?: string;
}

export default function TestWorkspace({ scenario, onScenarioChange, testSteps, onTestStepsChange }: TestWorkspaceProps) {
  const [stepsWithStatus, setStepsWithStatus] = useState<TestStepWithStatus[]>([]);
  const [elementPickerActive, setElementPickerActive] = useState(false);

  const { getDropHandlers } = useDragDrop();

  const handleStepAdd = (actionType: string) => {
    const newStep: TestStepData = {
      type: actionType as any,
      description: `New ${actionType} step`,
    };

    const newStepWithStatus: TestStepWithStatus = {
      id: `step-${Date.now()}`,
      ...newStep,
      status: 'pending',
    };

    onTestStepsChange([...testSteps, newStep]);
    setStepsWithStatus(prev => [...prev, newStepWithStatus]);
  };

  const getStepIcon = (type: string) => {
    const icons = {
      click: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
        </svg>
      ),
      type: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
        </svg>
      ),
      wait: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      screenshot: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
      assert: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      compare: (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
      ),
    };
    return icons[type as keyof typeof icons] || icons.click;
  };

  const getStepColorClass = (type: string) => {
    const colors = {
      click: "bg-primary/20",
      type: "bg-accent/20",
      wait: "bg-yellow-500/20",
      screenshot: "bg-green-500/20",
      assert: "bg-purple-500/20",
      compare: "bg-orange-500/20",
    };
    return colors[type as keyof typeof colors] || colors.click;
  };

  return (
    <div className="flex-1 flex flex-col" data-testid="test-workspace">
      {/* Test Scenario Header */}
      <div className="bg-card border-b border-border p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold" data-testid="scenario-title">
              {scenario?.name || 'New Test Scenario'}
            </h2>
            <p className="text-sm text-muted-foreground" data-testid="scenario-description">
              {scenario?.description || 'Drag test actions to build your scenario'}
            </p>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              className={cn(
                "text-muted-foreground hover:text-foreground",
                elementPickerActive && "text-primary"
              )}
              onClick={() => setElementPickerActive(!elementPickerActive)}
              data-testid="button-element-picker"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v1m0 0h10a2 2 0 012 2v11a2 2 0 01-2 2M9 7h10a2 2 0 012 2v11a2 2 0 01-2 2M9 7a2 2 0 00-2 2v11a2 2 0 002 2z" />
              </svg>
            </button>
            <span className="text-sm text-muted-foreground">
              Element Picker {elementPickerActive ? '(Active)' : ''}
            </span>
          </div>
        </div>
      </div>

      {/* Test Steps Drop Zone */}
      <div className="flex-1 p-4">
        <div 
          className="drop-zone rounded-lg p-6 min-h-96"
          {...getDropHandlers(handleStepAdd)}
          data-testid="drop-zone"
        >
          {stepsWithStatus.length > 0 ? (
            <div className="space-y-3">
              {stepsWithStatus.map((step, index) => (
                <div
                  key={step.id}
                  className={cn(
                    "test-step bg-card border border-border rounded-lg p-4 group",
                    step.status === 'running' && 'running',
                    step.status === 'passed' && 'passed',
                    step.status === 'failed' && 'failed'
                  )}
                  data-testid={`test-step-${index}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={cn(
                        "w-6 h-6 rounded-md flex items-center justify-center text-xs font-mono",
                        getStepColorClass(step.type)
                      )}>
                        {index + 1}
                      </div>
                      <div>
                        <div className="font-medium flex items-center space-x-2">
                          {getStepIcon(step.type)}
                          <span className="capitalize">{step.type} {step.type === 'type' ? 'Text' : step.type === 'assert' ? 'Element' : step.type === 'compare' ? 'Screenshots' : step.type === 'screenshot' ? 'Capture' : 'Action'}</span>
                        </div>
                        <div className="text-sm text-muted-foreground font-mono">
                          {step.selector && `${step.selector}${step.value ? ` → "${step.value}"` : ''}`}
                          {step.type === 'wait' && `${step.timeout || step.value || '1000'}ms`}
                          {step.type === 'screenshot' && step.description}
                          {!step.selector && step.type !== 'wait' && step.type !== 'screenshot' && 'Click to configure'}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {step.status === 'running' && (
                        <>
                          <div className="status-indicator status-running" />
                          <span className="text-sm text-yellow-500">Running</span>
                        </>
                      )}
                      {step.status === 'passed' && (
                        <>
                          <div className="status-indicator status-connected" />
                          <span className="text-sm text-green-500">Passed</span>
                        </>
                      )}
                      {step.status === 'failed' && (
                        <>
                          <div className="status-indicator status-disconnected" />
                          <span className="text-sm text-red-500">Failed</span>
                        </>
                      )}
                      {step.status === 'pending' && (
                        <span className="text-sm text-muted-foreground">Pending</span>
                      )}
                      <button 
                        className="text-destructive hover:text-destructive/80 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => {
                          onTestStepsChange(testSteps.filter((_, i) => i !== index));
                          setStepsWithStatus(prev => prev.filter((_, i) => i !== index));
                        }}
                        data-testid={`button-remove-step-${index}`}
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  </div>
                  {step.status === 'failed' && step.errorMessage && (
                    <div className="mt-2 text-sm text-red-500 bg-red-500/10 rounded p-2">
                      {step.errorMessage}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 text-muted-foreground">
              <svg className="w-12 h-12 mx-auto mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
              <p data-testid="drop-hint">Drag test actions here to build your scenario</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
