import { useCallback } from "react";

export interface DragDropHandlers {
  getDragHandlers: (actionType: string) => {
    onDragStart: (e: React.DragEvent) => void;
  };
  getDropHandlers: (onDrop: (actionType: string) => void) => {
    onDragOver: (e: React.DragEvent) => void;
    onDragLeave: (e: React.DragEvent) => void;
    onDrop: (e: React.DragEvent) => void;
  };
}

export function useDragDrop(): DragDropHandlers {
  const getDragHandlers = useCallback((actionType: string) => ({
    onDragStart: (e: React.DragEvent) => {
      e.dataTransfer.setData('text/plain', actionType);
      e.dataTransfer.effectAllowed = 'copy';
      
      // Add visual feedback
      const target = e.target as HTMLElement;
      target.style.opacity = '0.5';
      
      // Reset opacity after drag
      setTimeout(() => {
        target.style.opacity = '1';
      }, 0);
    },
  }), []);

  const getDropHandlers = useCallback((onDrop: (actionType: string) => void) => ({
    onDragOver: (e: React.DragEvent) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'copy';
      
      // Add visual feedback for drop zone
      const target = e.currentTarget as HTMLElement;
      target.classList.add('drag-over');
    },
    
    onDragLeave: (e: React.DragEvent) => {
      // Only remove class if we're leaving the drop zone itself, not a child
      const target = e.currentTarget as HTMLElement;
      const related = e.relatedTarget as Node | null;
      
      if (!related || !target.contains(related)) {
        target.classList.remove('drag-over');
      }
    },
    
    onDrop: (e: React.DragEvent) => {
      e.preventDefault();
      
      const target = e.currentTarget as HTMLElement;
      target.classList.remove('drag-over');
      
      const actionType = e.dataTransfer.getData('text/plain');
      if (actionType) {
        onDrop(actionType);
      }
    },
  }), []);

  return {
    getDragHandlers,
    getDropHandlers,
  };
}
