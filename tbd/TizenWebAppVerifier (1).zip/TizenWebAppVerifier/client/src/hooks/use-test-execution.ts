import { useState, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { TestRun, TestScenario } from "@shared/schema";

interface TestExecutionState {
  isRunning: boolean;
  currentStep: number | null;
  totalSteps: number;
  runId: string | null;
}

export function useTestExecution() {
  const [executionState, setExecutionState] = useState<TestExecutionState>({
    isRunning: false,
    currentStep: null,
    totalSteps: 0,
    runId: null,
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Run test mutation
  const runTestMutation = useMutation({
    mutationFn: async ({ scenarioId, deviceId }: { scenarioId: string; deviceId: string }) => {
      const response = await apiRequest('POST', `/api/scenarios/${scenarioId}/run`, { deviceId });
      return response.json() as Promise<TestRun>;
    },
    onSuccess: (testRun) => {
      setExecutionState({
        isRunning: true,
        currentStep: null,
        totalSteps: 0, // Will be updated from scenario data
        runId: testRun.id,
      });

      toast({
        title: "Test Started",
        description: "Test execution has begun",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to Start Test",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    },
  });

  const runTest = useCallback((scenarioId: string, deviceId: string) => {
    runTestMutation.mutate({ scenarioId, deviceId });
  }, [runTestMutation]);

  const stopTest = useCallback(() => {
    // TODO: Implement test stopping functionality
    setExecutionState({
      isRunning: false,
      currentStep: null,
      totalSteps: 0,
      runId: null,
    });
  }, []);

  const updateExecutionState = useCallback((updates: Partial<TestExecutionState>) => {
    setExecutionState(prev => ({ ...prev, ...updates }));
  }, []);

  return {
    executionState,
    runTest,
    stopTest,
    updateExecutionState,
    isExecuting: runTestMutation.isPending || executionState.isRunning,
  };
}
