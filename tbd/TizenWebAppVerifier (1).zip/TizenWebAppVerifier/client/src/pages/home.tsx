import Sidebar from "@/components/sidebar";
import TestBuilder from "@/components/test-builder";
import TestWorkspace from "@/components/test-workspace";
import DevicePanel from "@/components/device-panel";
import DeviceModal from "@/components/device-modal";
import { useState } from "react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Device, TestScenario, TestStepData } from "@shared/schema";

export default function Home() {
  const [activeTab, setActiveTab] = useState("builder");
  const [showDeviceModal, setShowDeviceModal] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [currentScenario, setCurrentScenario] = useState<TestScenario | null>(null);
  const [testSteps, setTestSteps] = useState<TestStepData[]>([]);

  const { toast } = useToast();
  
  // WebSocket connection for real-time updates
  useWebSocket();

  // Fetch devices
  const { data: devices = [], isLoading: devicesLoading } = useQuery<Device[]>({
    queryKey: ['/api/devices'],
  });

  // Fetch scenarios
  const { data: scenarios = [], isLoading: scenariosLoading } = useQuery<TestScenario[]>({
    queryKey: ['/api/scenarios'],
  });

  const connectedDevice = devices.find(device => device.status === 'connected') || null;

  // Save scenario mutation
  const saveScenarioMutation = useMutation({
    mutationFn: (scenarioData: { name: string; description?: string; steps: TestStepData[] }) => 
      apiRequest('/api/scenarios', {
        method: 'POST',
        body: JSON.stringify(scenarioData),
      }),
    onSuccess: (savedScenario: TestScenario) => {
      queryClient.invalidateQueries({ queryKey: ['/api/scenarios'] });
      setCurrentScenario(savedScenario);
      toast({
        title: "Success",
        description: "Test scenario saved successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error", 
        description: "Failed to save test scenario",
        variant: "destructive",
      });
    },
  });

  const handleSaveScenario = async () => {
    if (testSteps.length === 0) {
      toast({
        title: "No steps to save",
        description: "Please add some test steps before saving",
        variant: "destructive", 
      });
      return;
    }

    const scenarioName = prompt("Enter a name for your test scenario:");
    if (!scenarioName?.trim()) return;

    const scenarioDescription = prompt("Enter a description (optional):") || "";

    saveScenarioMutation.mutate({
      name: scenarioName.trim(),
      description: scenarioDescription.trim(),
      steps: testSteps,
    });
  };

  return (
    <div className="h-screen overflow-hidden flex" data-testid="main-container">
      {/* Sidebar Navigation */}
      <Sidebar 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        onDevicesClick={() => setShowDeviceModal(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="h-14 bg-card border-b border-border flex items-center justify-between px-6">
          <div className="flex items-center space-x-4">
            <h1 className="text-lg font-semibold" data-testid="page-title">
              Tizen Test Studio
            </h1>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <div 
                className={`status-indicator ${
                  connectedDevice ? 'status-connected' : 'status-disconnected'
                }`}
                data-testid="connection-status-indicator"
              />
              <span data-testid="connection-status-text">
                {connectedDevice ? `${connectedDevice.name} Connected` : 'No Device Connected'}
              </span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <button 
              className="bg-green-600 text-white px-3 py-2 rounded-md hover:bg-green-700 transition-colors text-sm"
              onClick={() => window.open('/api/scenarios/export', '_blank')}
              data-testid="button-export-scenarios"
            >
              <svg className="w-4 h-4 inline-block mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              Export
            </button>
            <button 
              className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors font-medium disabled:opacity-50"
              disabled={!connectedDevice || !currentScenario}
              data-testid="button-run-test"
            >
              <svg className="w-4 h-4 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Run Test
            </button>
            <button 
              className="bg-secondary text-secondary-foreground px-4 py-2 rounded-md hover:bg-secondary/90 transition-colors disabled:opacity-50"
              disabled={testSteps.length === 0 || saveScenarioMutation.isPending}
              onClick={handleSaveScenario}
              data-testid="button-save-scenario"
            >
              <svg className="w-4 h-4 inline-block mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
              </svg>
              {saveScenarioMutation.isPending ? "Saving..." : "Save Scenario"}
            </button>
          </div>
        </header>

        {/* Main Workspace */}
        <div className="flex-1 flex">
          {/* Test Builder Panel */}
          <TestBuilder />

          {/* Central Test Builder Area */}
          <TestWorkspace 
            scenario={currentScenario}
            onScenarioChange={setCurrentScenario}
            testSteps={testSteps}
            onTestStepsChange={setTestSteps}
          />

          {/* Right Panel - Device Preview */}
          <DevicePanel device={connectedDevice} />
        </div>

        {/* Bottom Status Bar */}
        <div className="h-10 bg-secondary border-t border-border flex items-center justify-between px-4 text-sm">
          <div className="flex items-center space-x-4">
            <span className="text-muted-foreground">Test Status:</span>
            <span className="text-muted-foreground" data-testid="test-status">
              Ready
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-muted-foreground" data-testid="last-saved">
              {testSteps.length > 0 ? `${testSteps.length} steps built` : 'Ready to build'}
            </span>
            <span className="text-muted-foreground">
              Chrome DevTools: {connectedDevice?.debugPort ? 'Connected' : 'Disconnected'}
            </span>
          </div>
        </div>
      </div>

      {/* Device Management Modal */}
      <DeviceModal 
        isOpen={showDeviceModal} 
        onClose={() => setShowDeviceModal(false)}
        devices={devices}
        onDeviceSelect={setSelectedDevice}
      />
    </div>
  );
}
