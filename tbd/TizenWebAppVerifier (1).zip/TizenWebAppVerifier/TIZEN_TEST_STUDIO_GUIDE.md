# Tizen Test Studio - Complete User Guide

## Overview

Tizen Test Studio is a web-based automated testing platform for Tizen devices including Samsung Smart TVs, Galaxy Watches, Family Hub refrigerators, and mobile devices. Create visual test scenarios, execute them on real devices, and get instant pass/fail results.

## Prerequisites

### Hardware Requirements
- Samsung Tizen device (Smart TV, Galaxy Watch, Family Hub, etc.)
- Development computer (Windows/Mac/Linux)
- USB cable or Wi-Fi network connection

### Software Setup
1. **Install Tizen Studio** from developer.tizen.org
2. **Add SDB to PATH**: Ensure `sdb` command is available globally
3. **Enable Developer Mode** on your Tizen device

## Getting Started

### Step 1: Enable Developer Mode on Device

**Samsung Smart TV:**
1. Go to Settings → General → System Manager → Developer Options
2. Turn ON "Developer Mode"
3. Note the IP address displayed

**Galaxy Watch:**
1. Settings → About watch → Software → tap Build number 5 times
2. Settings → Developer options → ADB debugging ON
3. Connect via USB or Wi-Fi

**Family Hub:**
1. Settings → Developer Options
2. Toggle "Developer Mode" ON
3. Note the IP address

### Step 2: Connect Device via SDB

Open terminal and connect your device:

```bash
# Connect to device
sdb connect [DEVICE_IP_ADDRESS]

# Verify connection
sdb devices
# Should show: [SERIAL] device [DEVICE_NAME]
```

### Step 3: Launch Test Studio

1. Open Tizen Test Studio in your web browser
2. Click the "Devices" tab in the sidebar
3. Click "Connect Device" and enter your device IP
4. Verify connection status shows "Connected"

## Building Test Scenarios

### Test Actions Available

**UI Interactions:**
- **Click Element**: Tap or click UI components
- **Type Text**: Enter text in input fields
- **Wait**: Pause execution for specified time
- **Screenshot**: Capture screen images

**Validations:**
- **Assert Element**: Verify element exists on screen
- **Visual Compare**: Compare screenshots for differences

### Creating Your First Test

1. **Start New Scenario**
   - The workspace shows "New Test Scenario" by default
   - Drag test actions from left panel to center workspace

2. **Add Test Steps**
   - Drag "Click" action to workspace
   - Click the step to configure selector (e.g., "#menu-button")
   - Add more steps as needed

3. **Configure Element Selectors**
   - Use CSS selectors: `#id`, `.class`, `button[type="submit"]`
   - Use XPath for complex targeting
   - Click "Element Picker" for visual selection

4. **Add Screenshots**
   - Drag "Screenshot" action where you want to capture images
   - Name your screenshots for easy identification

5. **Set Validation Points**
   - Use "Assert Element" to verify UI components exist
   - Use "Visual Compare" to detect layout changes

## Device Connection & Debug Mode

### Launching Apps in Debug Mode

1. **Open Device Modal**: Click "Devices" in sidebar
2. **Enter Package ID**: Input your app's package identifier
   - Example: `com.samsung.tv-settings`
   - Example: `com.example.myapp`
3. **Launch Debug**: Click "Launch Debug" button
4. **Verify Debug Port**: Check that debug port appears (e.g., 37846)

### Manual SDB Commands

The platform shows equivalent SDB commands for reference:

```bash
# List connected devices
sdb devices

# Launch app in debug mode
sdb shell 0 debug com.samsung.tv-settings

# Setup port forwarding
sdb forward tcp:37846 tcp:37846

# View device logs
sdb dlog
```

## Test Execution

### Running Tests

1. **Ensure Prerequisites**:
   - Device connected (green status indicator)
   - App launched in debug mode
   - Test scenario configured

2. **Execute Test**:
   - Click "Run Test" button in header
   - Watch real-time execution in workspace
   - Monitor progress in right panel

3. **View Results**:
   - See pass/fail status for each step
   - Review captured screenshots
   - Check error messages for failed steps

### Real-Time Monitoring

- **Step Status**: Green (passed), Red (failed), Yellow (running)
- **Live Logs**: View execution details in device panel
- **Screenshots**: Automatically captured and saved
- **Performance**: Monitor execution time and errors

## Family Hub Testing Examples

### WiFi Settings Test
```
1. Click Element: "#network-internet"
2. Screenshot: "network-menu"
3. Click Element: "#wifi-settings" 
4. Assert Element: ".wifi-list"
5. Screenshot: "wifi-list"
```

### SmartThings Integration Test
```
1. Click Element: "#smartthings-menu"
2. Wait: 3000ms
3. Assert Element: ".device-list"
4. Click Element: ".add-device-button"
5. Screenshot: "add-device-screen"
```

### Food Management Test
```
1. Click Element: "#food-management"
2. Click Element: "#expiration-alerts"
3. Assert Element: ".alert-settings"
4. Type Text: "#alert-days" → "2"
5. Click Element: "#save-settings"
6. Screenshot: "settings-saved"
```

## Smart TV Testing Examples

### App Navigation Test
```
1. Click Element: "#apps-menu"
2. Screenshot: "apps-grid"
3. Click Element: "[data-app='netflix']"
4. Wait: 5000ms
5. Assert Element: ".netflix-home"
6. Screenshot: "netflix-loaded"
```

### Settings Menu Test
```
1. Click Element: "#settings-button"
2. Click Element: "#display-settings"
3. Assert Element: ".brightness-slider"
4. Screenshot: "display-settings"
```

## Galaxy Watch Testing Examples

### Health App Test
```
1. Click Element: "#health-app"
2. Click Element: "#start-workout"
3. Assert Element: ".workout-timer"
4. Screenshot: "workout-active"
```

### Watch Face Test
```
1. Click Element: "#watch-faces"
2. Screenshot: "face-selection"
3. Click Element: ".face-digital"
4. Assert Element: ".face-preview"
```

## Advanced Features

### Element Picker

1. Click "Element Picker" button in workspace
2. Hover over elements in device preview
3. Click to auto-generate CSS selectors
4. Use generated selectors in test steps

### Screenshot Comparison

1. Take reference screenshot during test creation
2. Use "Visual Compare" action in test
3. Set acceptable difference percentage (default: 5%)
4. View diff images when comparison fails

### Custom Assertions

Add custom validation logic:
```javascript
// Example: Verify text content
document.querySelector('#status').textContent === 'Connected'

// Example: Check element count
document.querySelectorAll('.device-item').length > 0
```

## Troubleshooting

### Common Issues

**Device Won't Connect**
- Verify device IP address is correct
- Check Wi-Fi network connectivity
- Ensure Developer Mode is enabled
- Try USB connection instead

**Debug Mode Fails**
- Verify package ID is correct
- Check app is installed on device
- Ensure app supports web debugging
- Try restarting the app

**Test Steps Fail**
- Verify CSS selectors are correct
- Check element timing (add Wait steps)
- Ensure app is loaded before testing
- Use Element Picker for accurate targeting

**Screenshots Don't Match**
- Adjust comparison threshold percentage
- Account for dynamic content (timestamps, etc.)
- Use element-specific screenshots instead of full screen

### Best Practices

1. **Start Simple**: Begin with basic click and assert tests
2. **Add Waits**: Always wait for page loads and animations
3. **Use Screenshots**: Capture key states for visual verification
4. **Test Incrementally**: Build and test one step at a time
5. **Handle Dynamic Content**: Use flexible selectors for changing elements

## Supported Devices

### Verified Compatible
- Samsung Smart TVs (2018+)
- Galaxy Watch Series (Tizen 4.0+)
- Family Hub Refrigerators (2019+)
- Tizen Mobile Emulator

### App Requirements
- HTML/CSS/JavaScript applications
- Web-based or hybrid apps
- Apps that support Chrome DevTools debugging
- Must be launchable via `sdb shell 0 debug` command

## API Integration

The platform provides REST APIs for integration:

```bash
# Get connected devices
GET /api/devices

# Create test scenario
POST /api/scenarios

# Execute test
POST /api/scenarios/{id}/run

# Get test results
GET /api/runs/{id}
```

## Support

For issues or questions:
1. Check device connection status
2. Verify SDB commands work manually
3. Review browser console for errors
4. Check WebSocket connection in network tab

The platform automatically saves test scenarios and maintains execution history for debugging and replication.