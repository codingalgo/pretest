# Overview

Tizen Test Studio is a web-based automated testing platform designed for Tizen devices including smartwatches, TVs, mobile devices, and emulators. The application provides a visual test builder interface where users can create automated test scenarios through drag-and-drop interactions, execute tests on connected devices, and monitor results in real-time. The platform integrates with Samsung's SDB (Smart Development Bridge) for device management and uses Chrome DevTools Protocol for browser automation and screenshot capture.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React 18 using TypeScript and Vite as the build tool. The UI framework is based on shadcn/ui components with Radix UI primitives, styled using Tailwind CSS with a dark theme. The application uses Wouter for client-side routing and TanStack Query for server state management. Real-time communication is handled through WebSocket connections for live test execution updates and device status changes.

## Backend Architecture
The backend is an Express.js server using TypeScript with ESM modules. The server handles device management, test execution orchestration, and provides REST API endpoints for CRUD operations. WebSocket support is implemented using the 'ws' library for real-time communication with connected clients. The server integrates with external tools including SDB for Tizen device management, Chrome DevTools Protocol for browser automation, and image processing libraries for screenshot comparison.

## Data Storage Solutions
The application uses a simple JSON file-based storage system for test scenarios. Test sequences are automatically saved to `saved-scenarios.json` and loaded on startup. This provides persistent storage without database complexity. The system supports JSON export/import functionality allowing users to share test scenarios between different instances or create backups. Device information and test runs are stored in-memory for the current session.

## Device Integration
Device management is handled through Samsung's Smart Development Bridge (SDB), which provides capabilities for device discovery, connection management, application installation, and remote debugging. The system supports multiple device types including Galaxy Watches, Tizen TVs, mobile devices, and emulators. Each device maintains connection status, debugging port configuration, and unique serial identification.

## Test Automation Framework
Test execution uses Chrome DevTools Protocol for browser automation, enabling interaction with web applications running on Tizen devices. The framework supports various test actions including element clicking, text input, waiting periods, screenshot capture, and visual comparison. Test scenarios are defined as JSON structures containing step sequences, and execution results include screenshots, logs, and detailed step-by-step outcomes.

# External Dependencies

## Storage
- **JSON File Storage**: Simple file-based persistence for test scenarios
- **In-Memory Storage**: Fast access for devices and test runs during sessions
- **Export/Import**: JSON format for sharing and backing up test scenarios

## Device Management
- **Samsung SDB (Smart Development Bridge)**: Command-line tool for Tizen device management and debugging
- **Chrome DevTools Protocol**: Browser automation and inspection capabilities

## UI Framework
- **shadcn/ui**: Pre-built accessible UI components
- **Radix UI**: Unstyled, accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library for consistent iconography

## Real-time Communication
- **WebSocket (ws)**: Real-time bidirectional communication
- **TanStack Query**: Server state management and caching

## Image Processing
- **Sharp**: High-performance image processing for screenshot manipulation
- **Pixelmatch**: Pixel-level image comparison for visual testing
- **PNG.js**: PNG image format handling

## Development Tools
- **Vite**: Frontend build tool and development server
- **TypeScript**: Static type checking and enhanced developer experience
- **Replit Integration**: Development environment integration with runtime error handling