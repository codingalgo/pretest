import { type Device, type InsertDevice, type TestScenario, type InsertTestScenario, type TestRun, type InsertTestRun, type TestStep, type InsertTestStep } from "@shared/schema";
import { randomUUID } from "crypto";
import { promises as fs } from "fs";
import path from "path";

export interface IStorage {
  // Device methods
  getDevice(id: string): Promise<Device | undefined>;
  getDeviceBySerial(serial: string): Promise<Device | undefined>;
  getAllDevices(): Promise<Device[]>;
  createDevice(device: InsertDevice): Promise<Device>;
  updateDevice(id: string, updates: Partial<Device>): Promise<Device | undefined>;
  deleteDevice(id: string): Promise<boolean>;

  // Test scenario methods
  getTestScenario(id: string): Promise<TestScenario | undefined>;
  getAllTestScenarios(): Promise<TestScenario[]>;
  createTestScenario(scenario: InsertTestScenario): Promise<TestScenario>;
  updateTestScenario(id: string, updates: Partial<TestScenario>): Promise<TestScenario | undefined>;
  deleteTestScenario(id: string): Promise<boolean>;

  // Test run methods
  getTestRun(id: string): Promise<TestRun | undefined>;
  getTestRunsByScenario(scenarioId: string): Promise<TestRun[]>;
  createTestRun(run: InsertTestRun): Promise<TestRun>;
  updateTestRun(id: string, updates: Partial<TestRun>): Promise<TestRun | undefined>;

  // Test step methods
  getTestStepsByRun(runId: string): Promise<TestStep[]>;
  createTestStep(step: InsertTestStep): Promise<TestStep>;
  updateTestStep(id: string, updates: Partial<TestStep>): Promise<TestStep | undefined>;

  // JSON export/import methods
  exportScenariosToJSON(): Promise<string>;
  importScenariosFromJSON(jsonData: string): Promise<TestScenario[]>;
}

export class MemStorage implements IStorage {
  private devices: Map<string, Device> = new Map();
  protected testScenarios: Map<string, TestScenario> = new Map();
  private testRuns: Map<string, TestRun> = new Map();
  private testSteps: Map<string, TestStep> = new Map();

  // Device methods
  async getDevice(id: string): Promise<Device | undefined> {
    return this.devices.get(id);
  }

  async getDeviceBySerial(serial: string): Promise<Device | undefined> {
    return Array.from(this.devices.values()).find(device => device.serial === serial);
  }

  async getAllDevices(): Promise<Device[]> {
    return Array.from(this.devices.values());
  }

  async createDevice(insertDevice: InsertDevice): Promise<Device> {
    const id = randomUUID();
    const device: Device = {
      id,
      name: insertDevice.name,
      serial: insertDevice.serial,
      type: insertDevice.type,
      ipAddress: insertDevice.ipAddress ?? null,
      status: insertDevice.status ?? "disconnected",
      debugPort: insertDevice.debugPort ?? null,
      createdAt: new Date(),
    };
    this.devices.set(id, device);
    return device;
  }

  async updateDevice(id: string, updates: Partial<Device>): Promise<Device | undefined> {
    const device = this.devices.get(id);
    if (!device) return undefined;
    
    const updatedDevice = { ...device, ...updates };
    this.devices.set(id, updatedDevice);
    return updatedDevice;
  }

  async deleteDevice(id: string): Promise<boolean> {
    return this.devices.delete(id);
  }

  // Test scenario methods
  async getTestScenario(id: string): Promise<TestScenario | undefined> {
    return this.testScenarios.get(id);
  }

  async getAllTestScenarios(): Promise<TestScenario[]> {
    return Array.from(this.testScenarios.values());
  }

  async createTestScenario(insertScenario: InsertTestScenario): Promise<TestScenario> {
    const id = randomUUID();
    const scenario: TestScenario = {
      id,
      name: insertScenario.name,
      description: insertScenario.description ?? null,
      steps: insertScenario.steps ?? [],
      deviceId: insertScenario.deviceId ?? null,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.testScenarios.set(id, scenario);
    return scenario;
  }

  async updateTestScenario(id: string, updates: Partial<TestScenario>): Promise<TestScenario | undefined> {
    const scenario = this.testScenarios.get(id);
    if (!scenario) return undefined;
    
    const updatedScenario = { ...scenario, ...updates, updatedAt: new Date() };
    this.testScenarios.set(id, updatedScenario);
    return updatedScenario;
  }

  async deleteTestScenario(id: string): Promise<boolean> {
    return this.testScenarios.delete(id);
  }

  // Test run methods
  async getTestRun(id: string): Promise<TestRun | undefined> {
    return this.testRuns.get(id);
  }

  async getTestRunsByScenario(scenarioId: string): Promise<TestRun[]> {
    return Array.from(this.testRuns.values()).filter(run => run.scenarioId === scenarioId);
  }

  async createTestRun(insertRun: InsertTestRun): Promise<TestRun> {
    const id = randomUUID();
    const run: TestRun = {
      id,
      scenarioId: insertRun.scenarioId,
      deviceId: insertRun.deviceId,
      status: insertRun.status ?? "pending",
      startedAt: new Date(),
      completedAt: null,
      results: insertRun.results ?? [],
      screenshots: insertRun.screenshots ?? [],
      logs: insertRun.logs ?? null,
    };
    this.testRuns.set(id, run);
    return run;
  }

  async updateTestRun(id: string, updates: Partial<TestRun>): Promise<TestRun | undefined> {
    const run = this.testRuns.get(id);
    if (!run) return undefined;
    
    const updatedRun = { ...run, ...updates };
    this.testRuns.set(id, updatedRun);
    return updatedRun;
  }

  // Test step methods
  async getTestStepsByRun(runId: string): Promise<TestStep[]> {
    return Array.from(this.testSteps.values())
      .filter(step => step.runId === runId)
      .sort((a, b) => a.stepIndex - b.stepIndex);
  }

  async createTestStep(insertStep: InsertTestStep): Promise<TestStep> {
    const id = randomUUID();
    const step: TestStep = {
      id,
      runId: insertStep.runId,
      stepIndex: insertStep.stepIndex,
      type: insertStep.type,
      selector: insertStep.selector ?? null,
      value: insertStep.value ?? null,
      status: insertStep.status ?? "pending",
      startedAt: null,
      completedAt: null,
      errorMessage: insertStep.errorMessage ?? null,
      screenshot: insertStep.screenshot ?? null,
    };
    this.testSteps.set(id, step);
    return step;
  }

  async updateTestStep(id: string, updates: Partial<TestStep>): Promise<TestStep | undefined> {
    const step = this.testSteps.get(id);
    if (!step) return undefined;
    
    const updatedStep = { ...step, ...updates };
    this.testSteps.set(id, updatedStep);
    return updatedStep;
  }

  // Default implementations for export/import (no-op for base class)
  async exportScenariosToJSON(): Promise<string> {
    const scenarios = Array.from(this.testScenarios.values());
    return JSON.stringify({
      exportDate: new Date().toISOString(),
      scenarios: scenarios
    }, null, 2);
  }

  async importScenariosFromJSON(jsonData: string): Promise<TestScenario[]> {
    try {
      const data = JSON.parse(jsonData);
      const scenarios = data.scenarios || data;
      
      const importedScenarios: TestScenario[] = [];
      for (const scenarioData of scenarios) {
        const newId = randomUUID();
        const scenario: TestScenario = {
          ...scenarioData,
          id: newId,
          name: `${scenarioData.name} (Imported)`,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        
        this.testScenarios.set(newId, scenario);
        importedScenarios.push(scenario);
      }
      
      return importedScenarios;
    } catch (error) {
      throw new Error('Invalid JSON format');
    }
  }
}

export class FileStorage extends MemStorage {
  private scenariosFilePath: string;

  constructor() {
    super();
    this.scenariosFilePath = path.join(process.cwd(), 'saved-scenarios.json');
    this.loadScenariosFromFile();
  }

  private async loadScenariosFromFile(): Promise<void> {
    try {
      const data = await fs.readFile(this.scenariosFilePath, 'utf-8');
      const scenarios = JSON.parse(data) as TestScenario[];
      
      // Load scenarios into memory
      for (const scenario of scenarios) {
        this.testScenarios.set(scenario.id, scenario);
      }
      console.log(`Loaded ${scenarios.length} test scenarios from file`);
    } catch (error) {
      // File doesn't exist or is invalid, start with empty scenarios
      console.log('No existing scenarios file found, starting fresh');
    }
  }

  private async saveScenariosToFile(): Promise<void> {
    try {
      const scenarios = Array.from(this.testScenarios.values());
      await fs.writeFile(this.scenariosFilePath, JSON.stringify(scenarios, null, 2));
      console.log(`Saved ${scenarios.length} test scenarios to file`);
    } catch (error) {
      console.error('Failed to save scenarios to file:', error);
    }
  }

  // Override scenario methods to auto-save
  async createTestScenario(insertScenario: InsertTestScenario): Promise<TestScenario> {
    const scenario = await super.createTestScenario(insertScenario);
    await this.saveScenariosToFile();
    return scenario;
  }

  async updateTestScenario(id: string, updates: Partial<TestScenario>): Promise<TestScenario | undefined> {
    const scenario = await super.updateTestScenario(id, updates);
    if (scenario) {
      await this.saveScenariosToFile();
    }
    return scenario;
  }

  async deleteTestScenario(id: string): Promise<boolean> {
    const deleted = await super.deleteTestScenario(id);
    if (deleted) {
      await this.saveScenariosToFile();
    }
    return deleted;
  }

  // JSON export/import methods
  async exportScenariosToJSON(): Promise<string> {
    const scenarios = Array.from(this.testScenarios.values());
    return JSON.stringify({
      exportDate: new Date().toISOString(),
      scenarios: scenarios
    }, null, 2);
  }

  async importScenariosFromJSON(jsonData: string): Promise<TestScenario[]> {
    try {
      const data = JSON.parse(jsonData);
      const scenarios = data.scenarios || data; // Handle both formats
      
      const importedScenarios: TestScenario[] = [];
      for (const scenarioData of scenarios) {
        // Generate new ID to avoid conflicts
        const newId = randomUUID();
        const scenario: TestScenario = {
          ...scenarioData,
          id: newId,
          name: `${scenarioData.name} (Imported)`,
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        
        this.testScenarios.set(newId, scenario);
        importedScenarios.push(scenario);
      }
      
      await this.saveScenariosToFile();
      console.log(`Imported ${importedScenarios.length} test scenarios`);
      return importedScenarios;
    } catch (error) {
      console.error('Failed to import scenarios:', error);
      throw new Error('Invalid JSON format');
    }
  }
}

// Use FileStorage for simple JSON file-based storage
export const storage = new FileStorage();
