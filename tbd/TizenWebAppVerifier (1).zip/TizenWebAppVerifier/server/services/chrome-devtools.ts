import WebSocket from 'ws';
import fetch from 'node-fetch';

export interface ChromeDevToolsTarget {
  id: string;
  title: string;
  type: string;
  url: string;
  webSocketDebuggerUrl: string;
}

export interface ChromeDevToolsService {
  getTargets(port: number): Promise<ChromeDevToolsTarget[]>;
  connect(debuggerUrl: string): Promise<ChromeDevToolsConnection>;
}

export interface ChromeDevToolsConnection {
  send(method: string, params?: any): Promise<any>;
  on(event: string, callback: (data: any) => void): void;
  close(): void;
}

class ChromeDevToolsConnectionImpl implements ChromeDevToolsConnection {
  private ws: WebSocket;
  private messageId = 0;
  private pendingMessages = new Map<number, { resolve: Function; reject: Function }>();
  private eventListeners = new Map<string, Function[]>();

  constructor(ws: WebSocket) {
    this.ws = ws;
    this.setupMessageHandler();
  }

  private setupMessageHandler() {
    this.ws.on('message', (data: string) => {
      try {
        const message = JSON.parse(data);
        
        if (message.id !== undefined) {
          // Response to our request
          const pending = this.pendingMessages.get(message.id);
          if (pending) {
            this.pendingMessages.delete(message.id);
            if (message.error) {
              pending.reject(new Error(message.error.message));
            } else {
              pending.resolve(message.result);
            }
          }
        } else if (message.method) {
          // Event notification
          const listeners = this.eventListeners.get(message.method) || [];
          listeners.forEach(callback => callback(message.params));
        }
      } catch (error) {
        console.error('Failed to parse DevTools message:', error);
      }
    });
  }

  async send(method: string, params?: any): Promise<any> {
    const id = ++this.messageId;
    const message = { id, method, params };

    return new Promise((resolve, reject) => {
      this.pendingMessages.set(id, { resolve, reject });
      this.ws.send(JSON.stringify(message));

      // Timeout after 30 seconds
      setTimeout(() => {
        if (this.pendingMessages.has(id)) {
          this.pendingMessages.delete(id);
          reject(new Error(`DevTools command timeout: ${method}`));
        }
      }, 30000);
    });
  }

  on(event: string, callback: (data: any) => void): void {
    const listeners = this.eventListeners.get(event) || [];
    listeners.push(callback);
    this.eventListeners.set(event, listeners);
  }

  close(): void {
    this.ws.close();
  }
}

class ChromeDevToolsServiceImpl implements ChromeDevToolsService {
  async getTargets(port: number): Promise<ChromeDevToolsTarget[]> {
    try {
      const response = await fetch(`http://localhost:${port}/json`);
      const targets = await response.json() as ChromeDevToolsTarget[];
      return targets.filter(target => target.type === 'page');
    } catch (error) {
      console.error('Failed to get DevTools targets:', error);
      return [];
    }
  }

  async connect(debuggerUrl: string): Promise<ChromeDevToolsConnection> {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(debuggerUrl);
      
      ws.on('open', () => {
        resolve(new ChromeDevToolsConnectionImpl(ws));
      });

      ws.on('error', reject);
    });
  }
}

export const chromeDevToolsService = new ChromeDevToolsServiceImpl();

// Test automation utilities
export class TizenTestAutomation {
  private connection: ChromeDevToolsConnection;

  constructor(connection: ChromeDevToolsConnection) {
    this.connection = connection;
  }

  async enableDomainEvents(): Promise<void> {
    await this.connection.send('Runtime.enable');
    await this.connection.send('DOM.enable');
    await this.connection.send('Page.enable');
  }

  async clickElement(selector: string): Promise<void> {
    // Get document root
    const { root } = await this.connection.send('DOM.getDocument');
    
    // Query selector
    const { nodeId } = await this.connection.send('DOM.querySelector', {
      nodeId: root.nodeId,
      selector
    });

    if (!nodeId) {
      throw new Error(`Element not found: ${selector}`);
    }

    // Get element center point
    const { model } = await this.connection.send('DOM.getBoxModel', { nodeId });
    const [x1, y1, x2, y2] = model.content;
    const centerX = (x1 + x2) / 2;
    const centerY = (y1 + y2) / 2;

    // Simulate click
    await this.connection.send('Input.dispatchMouseEvent', {
      type: 'mousePressed',
      x: centerX,
      y: centerY,
      button: 'left',
      clickCount: 1
    });

    await this.connection.send('Input.dispatchMouseEvent', {
      type: 'mouseReleased',
      x: centerX,
      y: centerY,
      button: 'left',
      clickCount: 1
    });
  }

  async typeText(selector: string, text: string): Promise<void> {
    // Focus element first
    await this.clickElement(selector);

    // Type text character by character
    for (const char of text) {
      await this.connection.send('Input.dispatchKeyEvent', {
        type: 'char',
        text: char
      });
    }
  }

  async takeScreenshot(): Promise<string> {
    const { data } = await this.connection.send('Page.captureScreenshot', {
      format: 'png'
    });
    return data; // Base64 encoded image
  }

  async assertElement(selector: string): Promise<boolean> {
    try {
      const { root } = await this.connection.send('DOM.getDocument');
      const { nodeId } = await this.connection.send('DOM.querySelector', {
        nodeId: root.nodeId,
        selector
      });
      return nodeId !== 0;
    } catch (error) {
      return false;
    }
  }

  async wait(milliseconds: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  }
}
