import { spawn, exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

export interface SDBDevice {
  serial: string;
  status: string;
  name: string;
}

export interface SDBService {
  listDevices(): Promise<SDBDevice[]>;
  connectDevice(ipAddress: string): Promise<boolean>;
  disconnectDevice(serial: string): Promise<boolean>;
  installApp(serial: string, packagePath: string): Promise<boolean>;
  launchDebugApp(serial: string, packageId: string): Promise<{ pid: number; port: number }>;
  killApp(serial: string, packageId: string): Promise<boolean>;
  setupPortForward(serial: string, localPort: number, remotePort: number): Promise<boolean>;
  removePortForward(serial: string, localPort: number): Promise<boolean>;
  executeShellCommand(serial: string, command: string): Promise<string>;
  getDeviceLogs(serial: string, filter?: string): Promise<string>;
}

class SDBServiceImpl implements SDBService {
  private sdbPath: string;

  constructor() {
    // Use environment variable or default to 'sdb' assuming it's in PATH
    this.sdbPath = process.env.SDB_PATH || 'sdb';
  }

  async listDevices(): Promise<SDBDevice[]> {
    try {
      const { stdout } = await execAsync(`${this.sdbPath} devices`);
      const lines = stdout.trim().split('\n').filter(line => line.includes('device'));
      
      return lines.map(line => {
        const parts = line.trim().split(/\s+/);
        return {
          serial: parts[0],
          status: parts[1],
          name: parts[2] || 'Unknown Device',
        };
      });
    } catch (error) {
      console.error('Failed to list SDB devices:', error);
      return [];
    }
  }

  async connectDevice(ipAddress: string): Promise<boolean> {
    try {
      console.log(`Attempting to connect to device: ${ipAddress}`);
      const { stdout, stderr } = await execAsync(`${this.sdbPath} connect ${ipAddress}`);
      console.log('Connect stdout:', stdout);
      if (stderr) console.log('Connect stderr:', stderr);
      
      const success = !stderr && (stdout.includes('connected') || stdout.includes('already connected'));
      console.log('Connection result:', success);
      return success;
    } catch (error) {
      console.error('Failed to connect device:', error);
      return false;
    }
  }

  async disconnectDevice(serial: string): Promise<boolean> {
    try {
      console.log(`Attempting to disconnect device: ${serial}`);
      const { stdout, stderr } = await execAsync(`${this.sdbPath} -s ${serial} disconnect`);
      console.log('Disconnect stdout:', stdout);
      if (stderr) console.log('Disconnect stderr:', stderr);
      
      const success = !stderr || stdout.includes('disconnected');
      console.log('Disconnect result:', success);
      return success;
    } catch (error) {
      console.error('Failed to disconnect device:', error);
      return false;
    }
  }

  async installApp(serial: string, packagePath: string): Promise<boolean> {
    try {
      const { stdout, stderr } = await execAsync(`${this.sdbPath} -s ${serial} install "${packagePath}"`);
      return !stderr && stdout.includes('install complete');
    } catch (error) {
      console.error('Failed to install app:', error);
      return false;
    }
  }

  async launchDebugApp(serial: string, packageId: string): Promise<{ pid: number; port: number }> {
    try {
      console.log(`Attempting debug launch for ${packageId} on ${serial}`);
      
      // First try standard Tizen debug command
      let stdout, stderr;
      try {
        const result = await execAsync(`${this.sdbPath} -s ${serial} shell 0 debug ${packageId}`);
        stdout = result.stdout;
        stderr = result.stderr;
        console.log('Standard debug command output:', stdout);
      } catch (standardError) {
        console.log('Standard debug failed, trying Family Hub format...');
        
        // Try Family Hub specific debug command
        try {
          const result = await execAsync(`${this.sdbPath} -s ${serial} shell debug ${packageId}`);
          stdout = result.stdout;
          stderr = result.stderr;
          console.log('Family Hub debug command output:', stdout);
        } catch (familyHubError) {
          console.log('Family Hub debug failed, trying app launch with inspector...');
          
          // Try Family Hub app_launcher command
          const result = await execAsync(`${this.sdbPath} -s ${serial} shell app_launcher -s ${packageId}`);
          stdout = result.stdout;
          stderr = result.stderr;
          console.log('App launcher output:', stdout);
          
          // Family Hub app_launcher doesn't return debug info, but app launched successfully
          // We need to use the browser debugging approach for Family Hub
          if (stdout.includes('launched') || stdout.includes('started') || !stderr) {
            console.log('App launched successfully on Family Hub');
            return {
              pid: 1,
              port: 9222, // Chrome DevTools default port for Family Hub browser
            };
          }
        }
      }
      
      if (stderr) console.log('Debug launch stderr:', stderr);
      
      // Parse output: "successfully launched pid = 15900 with debug 1 port: 37846"
      const pidMatch = stdout.match(/pid = (\d+)/);
      const portMatch = stdout.match(/port: (\d+)/);
      
      if (pidMatch && portMatch) {
        const result = {
          pid: parseInt(pidMatch[1]),
          port: parseInt(portMatch[1]),
        };
        console.log('Parsed debug result:', result);
        return result;
      }
      
      // Try alternative Family Hub debug output format
      const altPortMatch = stdout.match(/debug port (\d+)/);
      const altPidMatch = stdout.match(/process (\d+)/);
      
      if (altPidMatch && altPortMatch) {
        const result = {
          pid: parseInt(altPidMatch[1]),
          port: parseInt(altPortMatch[1]),
        };
        console.log('Parsed alternative debug result:', result);
        return result;
      }
      
      // For Family Hub, if no specific debug info, use default inspector port
      if (stdout.includes('launched') || stdout.includes('started')) {
        console.log('App launched successfully, using default inspector port');
        return {
          pid: 1,
          port: 9229,
        };
      }
      
      throw new Error(`Failed to parse debug launch output: ${stdout}`);
    } catch (error) {
      console.error('Failed to launch debug app:', error);
      throw error;
    }
  }

  async killApp(serial: string, packageId: string): Promise<boolean> {
    try {
      const { stderr } = await execAsync(`${this.sdbPath} -s ${serial} shell 0 was_kill ${packageId}`);
      return !stderr;
    } catch (error) {
      console.error('Failed to kill app:', error);
      return false;
    }
  }

  async setupPortForward(serial: string, localPort: number, remotePort: number): Promise<boolean> {
    try {
      // Remove existing forward first
      await this.removePortForward(serial, localPort);
      
      const { stderr } = await execAsync(`${this.sdbPath} -s ${serial} forward tcp:${localPort} tcp:${remotePort}`);
      return !stderr;
    } catch (error) {
      console.error('Failed to setup port forwarding:', error);
      return false;
    }
  }

  async removePortForward(serial: string, localPort: number): Promise<boolean> {
    try {
      const { stderr } = await execAsync(`${this.sdbPath} -s ${serial} forward --remove tcp:${localPort}`);
      return true; // Don't fail if forward doesn't exist
    } catch (error) {
      return true; // Don't fail if forward doesn't exist
    }
  }

  async executeShellCommand(serial: string, command: string): Promise<string> {
    try {
      const { stdout } = await execAsync(`${this.sdbPath} -s ${serial} shell ${command}`);
      return stdout;
    } catch (error) {
      console.error('Failed to execute shell command:', error);
      throw error;
    }
  }

  async getDeviceLogs(serial: string, filter?: string): Promise<string> {
    try {
      const filterArg = filter ? ` ${filter}` : '';
      const { stdout } = await execAsync(`${this.sdbPath} -s ${serial} dlog${filterArg}`);
      return stdout;
    } catch (error) {
      console.error('Failed to get device logs:', error);
      return '';
    }
  }
}

export const sdbService = new SDBServiceImpl();
