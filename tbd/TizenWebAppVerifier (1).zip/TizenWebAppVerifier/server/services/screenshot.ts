import sharp from 'sharp';
import pixelmatch from 'pixelmatch';
import { PNG } from 'pngjs';
import { promises as fs } from 'fs';
import path from 'path';

export interface ScreenshotService {
  saveScreenshot(base64Data: string, filename: string): Promise<string>;
  compareScreenshots(screenshot1Path: string, screenshot2Path: string): Promise<ScreenshotComparison>;
  generateDiffImage(screenshot1Path: string, screenshot2Path: string, diffPath: string): Promise<void>;
}

export interface ScreenshotComparison {
  pixelDiff: number;
  percentageDiff: number;
  totalPixels: number;
  identical: boolean;
}

class ScreenshotServiceImpl implements ScreenshotService {
  private screenshotsDir: string;

  constructor() {
    this.screenshotsDir = path.join(process.cwd(), 'screenshots');
    this.ensureScreenshotsDir();
  }

  private async ensureScreenshotsDir(): Promise<void> {
    try {
      await fs.mkdir(this.screenshotsDir, { recursive: true });
    } catch (error) {
      console.error('Failed to create screenshots directory:', error);
    }
  }

  async saveScreenshot(base64Data: string, filename: string): Promise<string> {
    try {
      const buffer = Buffer.from(base64Data, 'base64');
      const filepath = path.join(this.screenshotsDir, filename);
      
      // Process image with sharp to ensure consistent format
      await sharp(buffer)
        .png()
        .toFile(filepath);
      
      return filepath;
    } catch (error) {
      console.error('Failed to save screenshot:', error);
      throw error;
    }
  }

  async compareScreenshots(screenshot1Path: string, screenshot2Path: string): Promise<ScreenshotComparison> {
    try {
      // Read both images
      const img1 = PNG.sync.read(await fs.readFile(screenshot1Path));
      const img2 = PNG.sync.read(await fs.readFile(screenshot2Path));

      // Ensure images have same dimensions
      if (img1.width !== img2.width || img1.height !== img2.height) {
        throw new Error('Screenshots have different dimensions');
      }

      const totalPixels = img1.width * img2.height;
      const pixelDiff = pixelmatch(img1.data, img2.data, null, img1.width, img1.height, {
        threshold: 0.1, // Pixel difference threshold (0-1)
        includeAA: false, // Ignore anti-aliasing
      });

      const percentageDiff = (pixelDiff / totalPixels) * 100;

      return {
        pixelDiff,
        percentageDiff,
        totalPixels,
        identical: pixelDiff === 0,
      };
    } catch (error) {
      console.error('Failed to compare screenshots:', error);
      throw error;
    }
  }

  async generateDiffImage(screenshot1Path: string, screenshot2Path: string, diffPath: string): Promise<void> {
    try {
      const img1 = PNG.sync.read(await fs.readFile(screenshot1Path));
      const img2 = PNG.sync.read(await fs.readFile(screenshot2Path));

      if (img1.width !== img2.width || img1.height !== img2.height) {
        throw new Error('Screenshots have different dimensions');
      }

      const diff = new PNG({ width: img1.width, height: img1.height });

      pixelmatch(img1.data, img2.data, diff.data, img1.width, img1.height, {
        threshold: 0.1,
        includeAA: false,
      });

      await fs.writeFile(diffPath, PNG.sync.write(diff));
    } catch (error) {
      console.error('Failed to generate diff image:', error);
      throw error;
    }
  }
}

export const screenshotService = new ScreenshotServiceImpl();
