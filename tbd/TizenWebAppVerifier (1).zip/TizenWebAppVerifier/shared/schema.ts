import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, boolean, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const devices = pgTable("devices", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  serial: text("serial").notNull().unique(),
  type: text("type").notNull(), // "watch", "tv", "mobile", "emulator"
  ipAddress: text("ip_address"),
  status: text("status").notNull().default("disconnected"), // "connected", "disconnected", "error"
  debugPort: integer("debug_port"),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const testScenarios = pgTable("test_scenarios", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  steps: jsonb("steps").notNull().default('[]'), // Array of test steps
  deviceId: varchar("device_id").references(() => devices.id),
  createdAt: timestamp("created_at").default(sql`now()`),
  updatedAt: timestamp("updated_at").default(sql`now()`),
});

export const testRuns = pgTable("test_runs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  scenarioId: varchar("scenario_id").references(() => testScenarios.id).notNull(),
  deviceId: varchar("device_id").references(() => devices.id).notNull(),
  status: text("status").notNull().default("pending"), // "pending", "running", "passed", "failed", "error"
  startedAt: timestamp("started_at").default(sql`now()`),
  completedAt: timestamp("completed_at"),
  results: jsonb("results").default('[]'), // Array of step results
  screenshots: jsonb("screenshots").default('[]'), // Array of screenshot paths
  logs: text("logs"),
});

export const testSteps = pgTable("test_steps", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  runId: varchar("run_id").references(() => testRuns.id).notNull(),
  stepIndex: integer("step_index").notNull(),
  type: text("type").notNull(), // "click", "type", "wait", "screenshot", "assert", "compare"
  selector: text("selector"),
  value: text("value"),
  status: text("status").notNull().default("pending"), // "pending", "running", "passed", "failed", "error"
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  errorMessage: text("error_message"),
  screenshot: text("screenshot"),
});

// Insert schemas
export const insertDeviceSchema = createInsertSchema(devices).omit({
  id: true,
  createdAt: true,
});

export const insertTestScenarioSchema = createInsertSchema(testScenarios).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTestRunSchema = createInsertSchema(testRuns).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

export const insertTestStepSchema = createInsertSchema(testSteps).omit({
  id: true,
  startedAt: true,
  completedAt: true,
});

// Types
export type Device = typeof devices.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type TestScenario = typeof testScenarios.$inferSelect;
export type InsertTestScenario = z.infer<typeof insertTestScenarioSchema>;
export type TestRun = typeof testRuns.$inferSelect;
export type InsertTestRun = z.infer<typeof insertTestRunSchema>;
export type TestStep = typeof testSteps.$inferSelect;
export type InsertTestStep = z.infer<typeof insertTestStepSchema>;

// Test step types
export type TestActionType = "click" | "type" | "wait" | "screenshot" | "assert" | "compare";

export interface TestStepData {
  type: TestActionType;
  selector?: string;
  value?: string;
  timeout?: number;
  description?: string;
}
