import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { sdbService } from "./services/sdb";
import { chromeDevToolsService, TizenTestAutomation } from "./services/chrome-devtools";
import { screenshotService } from "./services/screenshot";
import { insertDeviceSchema, insertTestScenarioSchema, insertTestRunSchema, type TestStepData } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const connectedClients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    connectedClients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      connectedClients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });
  });

  // Broadcast to all connected clients
  const broadcast = (message: any) => {
    const data = JSON.stringify(message);
    connectedClients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  };

  // Device management endpoints
  app.get('/api/devices', async (req, res) => {
    try {
      const devices = await storage.getAllDevices();
      res.json(devices);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch devices' });
    }
  });

  app.post('/api/devices', async (req, res) => {
    try {
      const deviceData = insertDeviceSchema.parse(req.body);
      const device = await storage.createDevice(deviceData);
      broadcast({ type: 'device_added', device });
      res.json(device);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid device data', details: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create device' });
      }
    }
  });

  app.put('/api/devices/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const device = await storage.updateDevice(id, updates);
      
      if (!device) {
        res.status(404).json({ error: 'Device not found' });
        return;
      }

      broadcast({ type: 'device_updated', device });
      res.json(device);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update device' });
    }
  });

  app.delete('/api/devices/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteDevice(id);
      
      if (!success) {
        res.status(404).json({ error: 'Device not found' });
        return;
      }

      broadcast({ type: 'device_deleted', deviceId: id });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete device' });
    }
  });

  // SDB integration endpoints
  app.get('/api/sdb/devices', async (req, res) => {
    try {
      const devices = await sdbService.listDevices();
      res.json(devices);
    } catch (error) {
      res.status(500).json({ error: 'Failed to list SDB devices' });
    }
  });

  app.post('/api/sdb/connect', async (req, res) => {
    try {
      const { ipAddress } = req.body;
      const success = await sdbService.connectDevice(ipAddress);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: 'Failed to connect device' });
    }
  });

  app.post('/api/sdb/disconnect/:serial', async (req, res) => {
    try {
      const { serial } = req.params;
      const success = await sdbService.disconnectDevice(serial);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: 'Failed to disconnect device' });
    }
  });

  app.post('/api/sdb/debug/:serial', async (req, res) => {
    try {
      const { serial } = req.params;
      const { packageId } = req.body;
      
      const result = await sdbService.launchDebugApp(serial, packageId);
      
      // Setup port forwarding
      await sdbService.setupPortForward(serial, result.port, result.port);
      
      // Update device with debug port
      const device = await storage.getDeviceBySerial(serial);
      if (device) {
        await storage.updateDevice(device.id, { 
          debugPort: result.port,
          status: 'connected' 
        });
      }

      res.json(result);
    } catch (error) {
      res.status(500).json({ error: 'Failed to launch debug app' });
    }
  });

  // Test scenario endpoints
  app.get('/api/scenarios', async (req, res) => {
    try {
      const scenarios = await storage.getAllTestScenarios();
      res.json(scenarios);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch test scenarios' });
    }
  });

  app.get('/api/scenarios/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const scenario = await storage.getTestScenario(id);
      
      if (!scenario) {
        res.status(404).json({ error: 'Scenario not found' });
        return;
      }

      res.json(scenario);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch scenario' });
    }
  });

  app.post('/api/scenarios', async (req, res) => {
    try {
      const scenarioData = insertTestScenarioSchema.parse(req.body);
      const scenario = await storage.createTestScenario(scenarioData);
      res.json(scenario);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: 'Invalid scenario data', details: error.errors });
      } else {
        res.status(500).json({ error: 'Failed to create scenario' });
      }
    }
  });

  app.put('/api/scenarios/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const scenario = await storage.updateTestScenario(id, updates);
      
      if (!scenario) {
        res.status(404).json({ error: 'Scenario not found' });
        return;
      }

      res.json(scenario);
    } catch (error) {
      res.status(500).json({ error: 'Failed to update scenario' });
    }
  });

  // Test execution endpoint
  app.post('/api/scenarios/:id/run', async (req, res) => {
    try {
      const { id: scenarioId } = req.params;
      const { deviceId } = req.body;

      const scenario = await storage.getTestScenario(scenarioId);
      const device = await storage.getDevice(deviceId);

      if (!scenario || !device) {
        res.status(404).json({ error: 'Scenario or device not found' });
        return;
      }

      if (!device.debugPort) {
        res.status(400).json({ error: 'Device is not in debug mode' });
        return;
      }

      // Create test run
      const testRun = await storage.createTestRun({
        scenarioId,
        deviceId,
        status: 'running',
        results: [],
        screenshots: [],
      });

      broadcast({ type: 'test_run_started', testRun });
      res.json(testRun);

      // Execute test in background
      executeTest(testRun.id, scenario.steps as TestStepData[], device.debugPort!, broadcast)
        .catch(error => {
          console.error('Test execution failed:', error);
          broadcast({ type: 'test_run_failed', runId: testRun.id, error: error.message });
        });

    } catch (error) {
      res.status(500).json({ error: 'Failed to start test run' });
    }
  });

  // JSON export/import endpoints
  app.get('/api/scenarios/export', async (req, res) => {
    try {
      const jsonData = await storage.exportScenariosToJSON();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', 'attachment; filename="test-scenarios.json"');
      res.send(jsonData);
    } catch (error) {
      res.status(500).json({ error: 'Failed to export scenarios' });
    }
  });

  app.post('/api/scenarios/import', async (req, res) => {
    try {
      const { jsonData } = req.body;
      const importedScenarios = await storage.importScenariosFromJSON(jsonData);
      res.json({ 
        success: true, 
        count: importedScenarios.length,
        scenarios: importedScenarios 
      });
    } catch (error) {
      res.status(400).json({ error: 'Failed to import scenarios: ' + (error as Error).message });
    }
  });

  // Test results endpoints
  app.get('/api/runs/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const run = await storage.getTestRun(id);
      
      if (!run) {
        res.status(404).json({ error: 'Test run not found' });
        return;
      }

      const steps = await storage.getTestStepsByRun(id);
      res.json({ ...run, steps });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch test run' });
    }
  });

  app.get('/api/scenarios/:id/runs', async (req, res) => {
    try {
      const { id } = req.params;
      const runs = await storage.getTestRunsByScenario(id);
      res.json(runs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch test runs' });
    }
  });

  return httpServer;
}

// Test execution function
async function executeTest(runId: string, steps: TestStepData[], debugPort: number, broadcast: Function) {
  let connection;
  
  try {
    // Connect to Chrome DevTools
    const targets = await chromeDevToolsService.getTargets(debugPort);
    const target = targets[0]; // Use first available target
    
    if (!target) {
      throw new Error('No debug target available');
    }

    connection = await chromeDevToolsService.connect(target.webSocketDebuggerUrl);
    const automation = new TizenTestAutomation(connection);
    await automation.enableDomainEvents();

    // Execute each step
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      
      // Create step record
      const testStep = await storage.createTestStep({
        runId,
        stepIndex: i,
        type: step.type,
        selector: step.selector || null,
        value: step.value || null,
        status: 'running',
      });

      broadcast({ 
        type: 'test_step_started', 
        runId, 
        stepIndex: i, 
        step: testStep 
      });

      try {
        await executeTestStep(automation, step, testStep.id);
        
        await storage.updateTestStep(testStep.id, {
          status: 'passed',
          completedAt: new Date(),
        });

        broadcast({ 
          type: 'test_step_completed', 
          runId, 
          stepIndex: i, 
          status: 'passed' 
        });

      } catch (error) {
        await storage.updateTestStep(testStep.id, {
          status: 'failed',
          errorMessage: error instanceof Error ? error.message : 'Unknown error',
          completedAt: new Date(),
        });

        broadcast({ 
          type: 'test_step_completed', 
          runId, 
          stepIndex: i, 
          status: 'failed',
          error: error instanceof Error ? error.message : 'Unknown error'
        });

        throw error; // Stop execution on failure
      }
    }

    // Mark run as completed
    await storage.updateTestRun(runId, {
      status: 'passed',
      completedAt: new Date(),
    });

    broadcast({ type: 'test_run_completed', runId, status: 'passed' });

  } catch (error) {
    await storage.updateTestRun(runId, {
      status: 'failed',
      completedAt: new Date(),
    });

    broadcast({ 
      type: 'test_run_completed', 
      runId, 
      status: 'failed',
      error: error instanceof Error ? error.message : 'Unknown error'
    });

  } finally {
    if (connection) {
      connection.close();
    }
  }
}

async function executeTestStep(automation: TizenTestAutomation, step: TestStepData, stepId: string) {
  switch (step.type) {
    case 'click':
      if (!step.selector) throw new Error('Selector required for click action');
      await automation.clickElement(step.selector);
      break;

    case 'type':
      if (!step.selector || !step.value) throw new Error('Selector and value required for type action');
      await automation.typeText(step.selector, step.value);
      break;

    case 'wait':
      const timeout = step.timeout || parseInt(step.value || '1000');
      await automation.wait(timeout);
      break;

    case 'screenshot':
      const screenshotData = await automation.takeScreenshot();
      const filename = `step-${stepId}-${Date.now()}.png`;
      const filepath = await screenshotService.saveScreenshot(screenshotData, filename);
      await storage.updateTestStep(stepId, { screenshot: filepath });
      break;

    case 'assert':
      if (!step.selector) throw new Error('Selector required for assert action');
      const exists = await automation.assertElement(step.selector);
      if (!exists) throw new Error(`Element not found: ${step.selector}`);
      break;

    case 'compare':
      // This would need reference screenshot path in step.value
      if (!step.value) throw new Error('Reference screenshot path required for compare action');
      const currentScreenshot = await automation.takeScreenshot();
      const currentFilename = `compare-${stepId}-${Date.now()}.png`;
      const currentPath = await screenshotService.saveScreenshot(currentScreenshot, currentFilename);
      
      const comparison = await screenshotService.compareScreenshots(step.value, currentPath);
      if (comparison.percentageDiff > 5) { // 5% threshold
        throw new Error(`Screenshots differ by ${comparison.percentageDiff.toFixed(2)}%`);
      }
      break;

    default:
      throw new Error(`Unsupported step type: ${step.type}`);
  }
}
