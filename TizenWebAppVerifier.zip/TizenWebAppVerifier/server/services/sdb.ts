import { spawn, exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

export interface SDBDevice {
  serial: string;
  status: string;
  name: string;
}

export interface SDBService {
  listDevices(): Promise<SDBDevice[]>;
  connectDevice(ipAddress: string): Promise<boolean>;
  disconnectDevice(serial: string): Promise<boolean>;
  installApp(serial: string, packagePath: string): Promise<boolean>;
  launchDebugApp(serial: string, packageId: string): Promise<{ pid: number; port: number }>;
  killApp(serial: string, packageId: string): Promise<boolean>;
  setupPortForward(serial: string, localPort: number, remotePort: number): Promise<boolean>;
  removePortForward(serial: string, localPort: number): Promise<boolean>;
  executeShellCommand(serial: string, command: string): Promise<string>;
  getDeviceLogs(serial: string, filter?: string): Promise<string>;
}

class SDBServiceImpl implements SDBService {
  private sdbPath: string;

  constructor() {
    // Use environment variable or default to 'sdb' assuming it's in PATH
    this.sdbPath = process.env.SDB_PATH || 'sdb';
  }

  async listDevices(): Promise<SDBDevice[]> {
    try {
      const { stdout } = await execAsync(`${this.sdbPath} devices`);
      const lines = stdout.trim().split('\n').filter(line => line.includes('device'));
      
      return lines.map(line => {
        const parts = line.trim().split(/\s+/);
        return {
          serial: parts[0],
          status: parts[1],
          name: parts[2] || 'Unknown Device',
        };
      });
    } catch (error) {
      console.error('Failed to list SDB devices:', error);
      return [];
    }
  }

  async connectDevice(ipAddress: string): Promise<boolean> {
    try {
      const { stdout, stderr } = await execAsync(`${this.sdbPath} connect ${ipAddress}`);
      return !stderr && (stdout.includes('connected') || stdout.includes('already connected'));
    } catch (error) {
      console.error('Failed to connect device:', error);
      return false;
    }
  }

  async disconnectDevice(serial: string): Promise<boolean> {
    try {
      const { stdout, stderr } = await execAsync(`${this.sdbPath} -s ${serial} disconnect`);
      return !stderr;
    } catch (error) {
      console.error('Failed to disconnect device:', error);
      return false;
    }
  }

  async installApp(serial: string, packagePath: string): Promise<boolean> {
    try {
      const { stdout, stderr } = await execAsync(`${this.sdbPath} -s ${serial} install "${packagePath}"`);
      return !stderr && stdout.includes('install complete');
    } catch (error) {
      console.error('Failed to install app:', error);
      return false;
    }
  }

  async launchDebugApp(serial: string, packageId: string): Promise<{ pid: number; port: number }> {
    try {
      const { stdout } = await execAsync(`${this.sdbPath} -s ${serial} shell 0 debug ${packageId}`);
      
      // Parse output: "successfully launched pid = 15900 with debug 1 port: 37846"
      const pidMatch = stdout.match(/pid = (\d+)/);
      const portMatch = stdout.match(/port: (\d+)/);
      
      if (pidMatch && portMatch) {
        return {
          pid: parseInt(pidMatch[1]),
          port: parseInt(portMatch[1]),
        };
      }
      
      throw new Error('Failed to parse debug launch output');
    } catch (error) {
      console.error('Failed to launch debug app:', error);
      throw error;
    }
  }

  async killApp(serial: string, packageId: string): Promise<boolean> {
    try {
      const { stderr } = await execAsync(`${this.sdbPath} -s ${serial} shell 0 was_kill ${packageId}`);
      return !stderr;
    } catch (error) {
      console.error('Failed to kill app:', error);
      return false;
    }
  }

  async setupPortForward(serial: string, localPort: number, remotePort: number): Promise<boolean> {
    try {
      // Remove existing forward first
      await this.removePortForward(serial, localPort);
      
      const { stderr } = await execAsync(`${this.sdbPath} -s ${serial} forward tcp:${localPort} tcp:${remotePort}`);
      return !stderr;
    } catch (error) {
      console.error('Failed to setup port forwarding:', error);
      return false;
    }
  }

  async removePortForward(serial: string, localPort: number): Promise<boolean> {
    try {
      const { stderr } = await execAsync(`${this.sdbPath} -s ${serial} forward --remove tcp:${localPort}`);
      return true; // Don't fail if forward doesn't exist
    } catch (error) {
      return true; // Don't fail if forward doesn't exist
    }
  }

  async executeShellCommand(serial: string, command: string): Promise<string> {
    try {
      const { stdout } = await execAsync(`${this.sdbPath} -s ${serial} shell ${command}`);
      return stdout;
    } catch (error) {
      console.error('Failed to execute shell command:', error);
      throw error;
    }
  }

  async getDeviceLogs(serial: string, filter?: string): Promise<string> {
    try {
      const filterArg = filter ? ` ${filter}` : '';
      const { stdout } = await execAsync(`${this.sdbPath} -s ${serial} dlog${filterArg}`);
      return stdout;
    } catch (error) {
      console.error('Failed to get device logs:', error);
      return '';
    }
  }
}

export const sdbService = new SDBServiceImpl();
