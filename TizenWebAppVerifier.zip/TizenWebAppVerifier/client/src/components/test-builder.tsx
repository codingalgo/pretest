import { useDragDrop } from "@/lib/drag-drop";
import type { TestActionType } from "@shared/schema";

interface TestAction {
  type: TestActionType;
  icon: React.ReactNode;
  color: string;
  title: string;
  description: string;
}

const testActions: TestAction[] = [
  {
    type: "click",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
      </svg>
    ),
    color: "bg-primary/20 text-primary",
    title: "Click Element",
    description: "Tap or click UI element"
  },
  {
    type: "type",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
      </svg>
    ),
    color: "bg-accent/20 text-accent",
    title: "Type Text",
    description: "Enter text input"
  },
  {
    type: "wait",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
    color: "bg-yellow-500/20 text-yellow-500",
    title: "Wait",
    description: "Pause execution"
  },
  {
    type: "screenshot",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
    color: "bg-green-500/20 text-green-500",
    title: "Screenshot",
    description: "Capture screen image"
  },
  {
    type: "assert",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
    color: "bg-purple-500/20 text-purple-500",
    title: "Assert Element",
    description: "Verify element exists"
  },
  {
    type: "compare",
    icon: (
      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    ),
    color: "bg-orange-500/20 text-orange-500",
    title: "Visual Compare",
    description: "Compare screenshots"
  }
];

export default function TestBuilder() {
  const { getDragHandlers } = useDragDrop();

  return (
    <div className="w-80 bg-card border-r border-border flex flex-col" data-testid="test-builder">
      {/* Tab Navigation */}
      <div className="border-b border-border">
        <div className="flex">
          <button className="tab-active px-4 py-3 text-sm font-medium border-b-2 border-accent" data-testid="tab-actions">
            Test Actions
          </button>
          <button className="px-4 py-3 text-sm font-medium text-muted-foreground hover:text-foreground" data-testid="tab-assertions">
            Assertions
          </button>
        </div>
      </div>

      {/* Action Library */}
      <div className="p-4 space-y-3 overflow-y-auto">
        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
          UI Interactions
        </h3>

        {/* UI Interaction Actions */}
        {testActions.slice(0, 4).map((action) => (
          <div
            key={action.type}
            className="drag-item bg-muted p-3 rounded-md cursor-grab"
            draggable
            {...getDragHandlers(action.type)}
            data-testid={`action-${action.type}`}
          >
            <div className="flex items-center space-x-3">
              <div className={`w-8 h-8 rounded-md flex items-center justify-center ${action.color}`}>
                {action.icon}
              </div>
              <div>
                <div className="font-medium text-sm">{action.title}</div>
                <div className="text-xs text-muted-foreground">{action.description}</div>
              </div>
            </div>
          </div>
        ))}

        <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide mt-6">
          Validations
        </h3>

        {/* Validation Actions */}
        {testActions.slice(4).map((action) => (
          <div
            key={action.type}
            className="drag-item bg-muted p-3 rounded-md cursor-grab"
            draggable
            {...getDragHandlers(action.type)}
            data-testid={`action-${action.type}`}
          >
            <div className="flex items-center space-x-3">
              <div className={`w-8 h-8 rounded-md flex items-center justify-center ${action.color}`}>
                {action.icon}
              </div>
              <div>
                <div className="font-medium text-sm">{action.title}</div>
                <div className="text-xs text-muted-foreground">{action.description}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
