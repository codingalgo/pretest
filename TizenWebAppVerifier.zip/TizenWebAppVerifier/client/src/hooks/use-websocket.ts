import { useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface WebSocketMessage {
  type: string;
  [key: string]: any;
}

export function useWebSocket() {
  const wsRef = useRef<WebSocket | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    // Determine WebSocket URL
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    // Create WebSocket connection
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      console.log("WebSocket connected");
    };

    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        handleWebSocketMessage(message);
      } catch (error) {
        console.error("Failed to parse WebSocket message:", error);
      }
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, []);

  const handleWebSocketMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'device_added':
      case 'device_updated':
      case 'device_deleted':
        queryClient.invalidateQueries({ queryKey: ['/api/devices'] });
        break;

      case 'test_run_started':
        toast({
          title: "Test Started",
          description: "Test execution has begun",
        });
        queryClient.invalidateQueries({ queryKey: ['/api/runs'] });
        break;

      case 'test_run_completed':
        const status = message.status === 'passed' ? 'success' : 'destructive';
        toast({
          title: "Test Completed",
          description: `Test ${message.status}`,
          variant: status === 'success' ? undefined : 'destructive',
        });
        queryClient.invalidateQueries({ queryKey: ['/api/runs'] });
        break;

      case 'test_run_failed':
        toast({
          title: "Test Failed",
          description: message.error || "Test execution failed",
          variant: "destructive",
        });
        break;

      case 'test_step_started':
        // Update UI to show running step
        console.log(`Step ${message.stepIndex + 1} started`);
        break;

      case 'test_step_completed':
        console.log(`Step ${message.stepIndex + 1} completed: ${message.status}`);
        if (message.status === 'failed') {
          toast({
            title: "Step Failed",
            description: message.error || `Step ${message.stepIndex + 1} failed`,
            variant: "destructive",
          });
        }
        break;

      default:
        console.log("Unknown WebSocket message type:", message.type);
    }
  };

  const sendMessage = (message: WebSocketMessage) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(message));
    }
  };

  return { sendMessage };
}
